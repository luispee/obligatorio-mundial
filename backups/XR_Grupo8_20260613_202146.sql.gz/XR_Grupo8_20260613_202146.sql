-- MySQL dump 10.13  Distrib 8.0.39, for Win64 (x86_64)
--
-- Host: mysql.reto-ucu.net    Database: XR_Grupo8
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrador` (
  `mail` varchar(255) NOT NULL,
  `fecha_asignacion` date NOT NULL,
  `codigo_pais_sede` char(3) NOT NULL,
  PRIMARY KEY (`mail`),
  KEY `fk_admin_pais_sede` (`codigo_pais_sede`),
  CONSTRAINT `fk_admin_pais_sede` FOREIGN KEY (`codigo_pais_sede`) REFERENCES `pais_sede` (`codigo_pais`),
  CONSTRAINT `fk_admin_usuario` FOREIGN KEY (`mail`) REFERENCES `usuario` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
INSERT INTO `administrador` VALUES ('adminCAN@fifa.com','2026-06-09','CAN'),('adminMEX@fifa.com','2026-06-09','MEX'),('adminUSA@fifa.com','2026-06-09','USA');
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `mail` varchar(255) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `verificado` tinyint(1) NOT NULL,
  PRIMARY KEY (`mail`),
  CONSTRAINT `fk_cliente_usuario` FOREIGN KEY (`mail`) REFERENCES `usuario` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES ('mateo@gmail.com','2026-06-11 19:14:33',0),('user1000@example.com','2026-06-11 20:38:16',0),('user123@algo.com','2026-06-11 16:52:48',0),('user12@example.com','2026-06-11 01:52:15',0),('user13@example.com','2026-06-11 13:08:25',0),('user14@bolso.com','2026-06-11 01:51:27',0),('user14@example.com','2026-06-13 03:16:21',0),('user15@example.com','2026-06-11 01:57:46',0),('user1899@bolso.com','2026-06-11 01:50:05',0),('user1@example.com','2026-06-10 10:10:59',0),('user2@example.com','2026-06-10 10:28:55',0),('user4@example.com','2026-06-10 15:16:52',0),('usuario@example.com','2026-06-11 02:14:49',0);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispositivo`
--

DROP TABLE IF EXISTS `dispositivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispositivo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modelo` varchar(100) NOT NULL,
  `numero_serie` varchar(100) NOT NULL,
  `operativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_serie` (`numero_serie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispositivo`
--

LOCK TABLES `dispositivo` WRITE;
/*!40000 ALTER TABLE `dispositivo` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispositivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrada`
--

DROP TABLE IF EXISTS `entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrada` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad_transferencias` int NOT NULL DEFAULT '0',
  `usada` tinyint(1) NOT NULL DEFAULT '0',
  `mail_cliente_propietario` varchar(255) NOT NULL,
  `id_venta` bigint NOT NULL,
  `id_sector` int NOT NULL,
  `id_evento` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_entrada_cliente` (`mail_cliente_propietario`),
  KEY `fk_entrada_venta` (`id_venta`),
  KEY `fk_entrada_sector_evento` (`id_sector`,`id_evento`),
  CONSTRAINT `fk_entrada_cliente` FOREIGN KEY (`mail_cliente_propietario`) REFERENCES `cliente` (`mail`),
  CONSTRAINT `fk_entrada_sector_evento` FOREIGN KEY (`id_sector`, `id_evento`) REFERENCES `sector_evento` (`id_sector`, `id_evento`),
  CONSTRAINT `fk_entrada_venta` FOREIGN KEY (`id_venta`) REFERENCES `venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrada`
--

LOCK TABLES `entrada` WRITE;
/*!40000 ALTER TABLE `entrada` DISABLE KEYS */;
/*!40000 ALTER TABLE `entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estadio`
--

DROP TABLE IF EXISTS `estadio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estadio` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `codigo_pais_sede` char(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_estadio_pais_sede` (`codigo_pais_sede`),
  CONSTRAINT `fk_estadio_pais_sede` FOREIGN KEY (`codigo_pais_sede`) REFERENCES `pais_sede` (`codigo_pais`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estadio`
--

LOCK TABLES `estadio` WRITE;
/*!40000 ALTER TABLE `estadio` DISABLE KEYS */;
INSERT INTO `estadio` VALUES (1,'BMO Field','Toronto','CAN'),(2,'BC Place','Vancouver','CAN'),(3,'Estadio Azteca','Ciudad de México','MEX'),(4,'Estadio Akron','Guadalajara','MEX'),(5,'Estadio BBVA','Monterrey','MEX'),(6,'Mercedes-Benz Stadium','Atlanta','USA'),(7,'Gillette Stadium','Boston','USA'),(8,'AT&T Stadium','Dallas','USA'),(9,'NRG Stadium','Houston','USA'),(10,'Arrowhead Stadium','Kansas City','USA'),(11,'SoFi Stadium','Los Ángeles','USA'),(12,'Hard Rock Stadium','Miami','USA'),(13,'MetLife Stadium','New Jersey','USA'),(14,'Lincoln Financial Field','Philadelphia','USA'),(15,'Levi\'s Stadium','San Francisco','USA'),(16,'Lumen Field','Seattle','USA');
/*!40000 ALTER TABLE `estadio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado_transferencia`
--

DROP TABLE IF EXISTS `estado_transferencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estado_transferencia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estado` (`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_transferencia`
--

LOCK TABLES `estado_transferencia` WRITE;
/*!40000 ALTER TABLE `estado_transferencia` DISABLE KEYS */;
INSERT INTO `estado_transferencia` VALUES (2,'Completada'),(1,'Pendiente'),(3,'Rechazada');
/*!40000 ALTER TABLE `estado_transferencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado_venta`
--

DROP TABLE IF EXISTS `estado_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estado_venta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estado` (`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_venta`
--

LOCK TABLES `estado_venta` WRITE;
/*!40000 ALTER TABLE `estado_venta` DISABLE KEYS */;
INSERT INTO `estado_venta` VALUES (3,'Cancelada'),(2,'Pagada'),(1,'Pendiente');
/*!40000 ALTER TABLE `estado_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evento`
--

DROP TABLE IF EXISTS `evento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha_hora` datetime NOT NULL,
  `codigo_seleccion_local` char(3) NOT NULL,
  `codigo_seleccion_visitante` char(3) NOT NULL,
  `id_estadio` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_evento_local` (`codigo_seleccion_local`),
  KEY `fk_evento_visitante` (`codigo_seleccion_visitante`),
  KEY `fk_evento_estadio` (`id_estadio`),
  CONSTRAINT `fk_evento_estadio` FOREIGN KEY (`id_estadio`) REFERENCES `estadio` (`id`),
  CONSTRAINT `fk_evento_local` FOREIGN KEY (`codigo_seleccion_local`) REFERENCES `seleccion` (`codigo_pais`),
  CONSTRAINT `fk_evento_visitante` FOREIGN KEY (`codigo_seleccion_visitante`) REFERENCES `seleccion` (`codigo_pais`),
  CONSTRAINT `chk_selecciones_distintas` CHECK ((`codigo_seleccion_local` <> `codigo_seleccion_visitante`))
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evento`
--

LOCK TABLES `evento` WRITE;
/*!40000 ALTER TABLE `evento` DISABLE KEYS */;
INSERT INTO `evento` VALUES (41,'2026-06-15 20:00:00','ARG','FRA',2),(42,'2026-06-17 10:47:00','ARG','AUS',10),(43,'2026-06-27 11:05:00','ARG','BEL',10),(44,'2026-06-23 11:07:00','ARG','ITA',15),(45,'2026-06-26 11:09:00','ARG','AUT',15),(46,'2026-07-10 11:36:00','DZA','AUS',8),(47,'2026-07-05 12:40:00','AUT','BIH',3),(48,'2026-07-04 11:42:00','AUS','QAT',10),(49,'2026-06-16 11:44:00','GHA','URY',8),(50,'2026-07-05 11:46:00','AUT','CZE',8),(51,'2026-09-18 11:50:00','DEU','JPN',13),(52,'2026-06-28 11:00:00','TUN','SEN',9),(53,'2026-06-19 11:58:00','AUS','BEL',8),(54,'2026-07-02 12:01:00','UZB','IRN',9),(55,'2026-07-05 12:09:00','DZA','NLD',16),(56,'2030-06-06 12:11:00','DZA','AUT',15),(57,'2026-06-26 12:14:00','JPN','JOR',3),(58,'2026-06-14 14:00:00','AUS','IRQ',2);
/*!40000 ALTER TABLE `evento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionario` (
  `mail` varchar(255) NOT NULL,
  `numero_legajo` varchar(50) NOT NULL,
  PRIMARY KEY (`mail`),
  UNIQUE KEY `numero_legajo` (`numero_legajo`),
  CONSTRAINT `fk_funcionario_usuario` FOREIGN KEY (`mail`) REFERENCES `usuario` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES ('funcionario1@fifa.com','1001'),('funcionario2@fifa.com','1002');
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario_dispositivo`
--

DROP TABLE IF EXISTS `funcionario_dispositivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionario_dispositivo` (
  `mail_funcionario` varchar(255) NOT NULL,
  `id_dispositivo` int NOT NULL,
  PRIMARY KEY (`mail_funcionario`,`id_dispositivo`),
  KEY `fk_fd_dispositivo` (`id_dispositivo`),
  CONSTRAINT `fk_fd_dispositivo` FOREIGN KEY (`id_dispositivo`) REFERENCES `dispositivo` (`id`),
  CONSTRAINT `fk_fd_funcionario` FOREIGN KEY (`mail_funcionario`) REFERENCES `funcionario` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario_dispositivo`
--

LOCK TABLES `funcionario_dispositivo` WRITE;
/*!40000 ALTER TABLE `funcionario_dispositivo` DISABLE KEYS */;
/*!40000 ALTER TABLE `funcionario_dispositivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mensaje` varchar(255) DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11719 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pais`
--

DROP TABLE IF EXISTS `pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pais` (
  `codigo` char(3) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pais`
--

LOCK TABLES `pais` WRITE;
/*!40000 ALTER TABLE `pais` DISABLE KEYS */;
INSERT INTO `pais` VALUES ('AFG','Afghanistan'),('ALA','Åland Islands'),('ALB','Albania'),('DZA','Algeria'),('ASM','American Samoa'),('AND','Andorra'),('AGO','Angola'),('AIA','Anguilla'),('ATA','Antarctica'),('ATG','Antigua and Barbuda'),('ARG','Argentina'),('ARM','Armenia'),('ABW','Aruba'),('AUS','Australia'),('AUT','Austria'),('AZE','Azerbaijan'),('BHS','Bahamas'),('BHR','Bahrain'),('BGD','Bangladesh'),('BRB','Barbados'),('BLR','Belarus'),('BEL','Belgium'),('BLZ','Belize'),('BEN','Benin'),('BMU','Bermuda'),('BTN','Bhutan'),('BOL','Bolivia'),('BIH','Bosnia and Herzegovina'),('BWA','Botswana'),('BVT','Bouvet Island'),('BRA','Brazil'),('IOT','British Indian Ocean Territory'),('VGB','British Virgin Islands'),('BRN','Brunei'),('BGR','Bulgaria'),('BFA','Burkina Faso'),('BDI','Burundi'),('KHM','Cambodia'),('CMR','Cameroon'),('CAN','Canada'),('CPV','Cape Verde'),('BES','Caribbean Netherlands'),('CYM','Cayman Islands'),('CAF','Central African Republic'),('TCD','Chad'),('CHL','Chile'),('CHN','China'),('CXR','Christmas Island'),('CCK','Cocos (Keeling) Islands'),('COL','Colombia'),('COM','Comoros'),('COK','Cook Islands'),('CRI','Costa Rica'),('HRV','Croatia'),('CUB','Cuba'),('CUW','Curaçao'),('CYP','Cyprus'),('CZE','Czechia'),('DNK','Denmark'),('DJI','Djibouti'),('DMA','Dominica'),('DOM','Dominican Republic'),('COD','DR Congo'),('ECU','Ecuador'),('EGY','Egypt'),('SLV','El Salvador'),('GNQ','Equatorial Guinea'),('ERI','Eritrea'),('EST','Estonia'),('SWZ','Eswatini'),('ETH','Ethiopia'),('FLK','Falkland Islands'),('FRO','Faroe Islands'),('FJI','Fiji'),('FIN','Finland'),('FRA','France'),('GUF','French Guiana'),('PYF','French Polynesia'),('ATF','French Southern and Antarctic Lands'),('GAB','Gabon'),('GMB','Gambia'),('GEO','Georgia'),('DEU','Germany'),('GHA','Ghana'),('GIB','Gibraltar'),('GRC','Greece'),('GRL','Greenland'),('GRD','Grenada'),('GLP','Guadeloupe'),('GUM','Guam'),('GTM','Guatemala'),('GGY','Guernsey'),('GIN','Guinea'),('GNB','Guinea-Bissau'),('GUY','Guyana'),('HTI','Haiti'),('HMD','Heard Island and McDonald Islands'),('HND','Honduras'),('HKG','Hong Kong'),('HUN','Hungary'),('ISL','Iceland'),('IND','India'),('IDN','Indonesia'),('IRN','Iran'),('IRQ','Iraq'),('IRL','Ireland'),('IMN','Isle of Man'),('ISR','Israel'),('ITA','Italy'),('CIV','Ivory Coast'),('JAM','Jamaica'),('JPN','Japan'),('JEY','Jersey'),('JOR','Jordan'),('KAZ','Kazakhstan'),('KEN','Kenya'),('UNK','Kosovo'),('KWT','Kuwait'),('KGZ','Kyrgyzstan'),('LAO','Laos'),('LVA','Latvia'),('LBN','Lebanon'),('LSO','Lesotho'),('LBR','Liberia'),('LBY','Libya'),('LIE','Liechtenstein'),('LTU','Lithuania'),('LUX','Luxembourg'),('MAC','Macau'),('MDG','Madagascar'),('MWI','Malawi'),('MYS','Malaysia'),('MDV','Maldives'),('MLI','Mali'),('MLT','Malta'),('MHL','Marshall Islands'),('MTQ','Martinique'),('MRT','Mauritania'),('MUS','Mauritius'),('MYT','Mayotte'),('MEX','Mexico'),('FSM','Micronesia'),('MDA','Moldova'),('MCO','Monaco'),('MNG','Mongolia'),('MNE','Montenegro'),('MSR','Montserrat'),('MAR','Morocco'),('MOZ','Mozambique'),('MMR','Myanmar'),('NAM','Namibia'),('NRU','Nauru'),('NPL','Nepal'),('NLD','Netherlands'),('NCL','New Caledonia'),('NZL','New Zealand'),('NIC','Nicaragua'),('NER','Niger'),('NGA','Nigeria'),('NIU','Niue'),('NFK','Norfolk Island'),('PRK','North Korea'),('MKD','North Macedonia'),('MNP','Northern Mariana Islands'),('NOR','Norway'),('OMN','Oman'),('PAK','Pakistan'),('PLW','Palau'),('PSE','Palestine'),('PAN','Panama'),('PNG','Papua New Guinea'),('PRY','Paraguay'),('PER','Peru'),('PHL','Philippines'),('PCN','Pitcairn Islands'),('POL','Poland'),('PRT','Portugal'),('PRI','Puerto Rico'),('QAT','Qatar'),('COG','Republic of the Congo'),('REU','Réunion'),('ROU','Romania'),('RUS','Russia'),('RWA','Rwanda'),('BLM','Saint Barthélemy'),('SHN','Saint Helena, Ascension and Tristan da Cunha'),('KNA','Saint Kitts and Nevis'),('LCA','Saint Lucia'),('MAF','Saint Martin'),('SPM','Saint Pierre and Miquelon'),('VCT','Saint Vincent and the Grenadines'),('WSM','Samoa'),('SMR','San Marino'),('STP','São Tomé and Príncipe'),('SAU','Saudi Arabia'),('SEN','Senegal'),('SRB','Serbia'),('SYC','Seychelles'),('SLE','Sierra Leone'),('SGP','Singapore'),('SXM','Sint Maarten'),('SVK','Slovakia'),('SLB','Solomon Islands'),('SOM','Somalia'),('ZAF','South Africa'),('SGS','South Georgia'),('KOR','South Korea'),('SSD','South Sudan'),('ESP','Spain'),('LKA','Sri Lanka'),('SDN','Sudan'),('SUR','Suriname'),('SJM','Svalbard and Jan Mayen'),('SWE','Sweden'),('CHE','Switzerland'),('SYR','Syria'),('TWN','Taiwan'),('TJK','Tajikistan'),('TZA','Tanzania'),('THA','Thailand'),('TLS','Timor-Leste'),('TGO','Togo'),('TKL','Tokelau'),('TON','Tonga'),('TTO','Trinidad and Tobago'),('TUN','Tunisia'),('TUR','Turkey'),('TKM','Turkmenistan'),('TCA','Turks and Caicos Islands'),('TUV','Tuvalu'),('UGA','Uganda'),('UKR','Ukraine'),('ARE','United Arab Emirates'),('GBR','United Kingdom'),('USA','United States'),('UMI','United States Minor Outlying Islands'),('VIR','United States Virgin Islands'),('URY','Uruguay'),('UZB','Uzbekistan'),('VUT','Vanuatu'),('VAT','Vatican City'),('VEN','Venezuela'),('VNM','Vietnam'),('WLF','Wallis and Futuna'),('ESH','Western Sahara'),('YEM','Yemen'),('ZMB','Zambia'),('ZWE','Zimbabwe');
/*!40000 ALTER TABLE `pais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pais_sede`
--

DROP TABLE IF EXISTS `pais_sede`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pais_sede` (
  `codigo_pais` char(3) NOT NULL,
  PRIMARY KEY (`codigo_pais`),
  CONSTRAINT `fk_pais_sede_pais` FOREIGN KEY (`codigo_pais`) REFERENCES `pais` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pais_sede`
--

LOCK TABLES `pais_sede` WRITE;
/*!40000 ALTER TABLE `pais_sede` DISABLE KEYS */;
INSERT INTO `pais_sede` VALUES ('CAN'),('MEX'),('USA');
/*!40000 ALTER TABLE `pais_sede` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sector`
--

DROP TABLE IF EXISTS `sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sector` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `capacidad_maxima` int NOT NULL,
  `id_estadio` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sector_estadio` (`id_estadio`),
  CONSTRAINT `fk_sector_estadio` FOREIGN KEY (`id_estadio`) REFERENCES `estadio` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector`
--

LOCK TABLES `sector` WRITE;
/*!40000 ALTER TABLE `sector` DISABLE KEYS */;
INSERT INTO `sector` VALUES (1,'Tribuna Norte',9000,1),(2,'Tribuna Sur',9000,1),(3,'Tribuna Este',13500,1),(4,'Tribuna Oeste',13500,1),(5,'Tribuna Norte',10800,2),(6,'Tribuna Sur',10800,2),(7,'Tribuna Este',16200,2),(8,'Tribuna Oeste',16200,2),(9,'Tribuna Norte',16600,3),(10,'Tribuna Sur',16600,3),(11,'Tribuna Este',24900,3),(12,'Tribuna Oeste',24900,3),(13,'Tribuna Norte',9600,4),(14,'Tribuna Sur',9600,4),(15,'Tribuna Este',14400,4),(16,'Tribuna Oeste',14400,4),(17,'Tribuna Norte',10700,5),(18,'Tribuna Sur',10700,5),(19,'Tribuna Este',16050,5),(20,'Tribuna Oeste',16050,5),(21,'Tribuna Norte',15000,6),(22,'Tribuna Sur',15000,6),(23,'Tribuna Este',22500,6),(24,'Tribuna Oeste',22500,6),(25,'Tribuna Norte',13000,7),(26,'Tribuna Sur',13000,7),(27,'Tribuna Este',19500,7),(28,'Tribuna Oeste',19500,7),(29,'Tribuna Norte',18800,8),(30,'Tribuna Sur',18800,8),(31,'Tribuna Este',28200,8),(32,'Tribuna Oeste',28200,8),(33,'Tribuna Norte',14444,9),(34,'Tribuna Sur',14444,9),(35,'Tribuna Este',21666,9),(36,'Tribuna Oeste',21666,9),(37,'Tribuna Norte',14600,10),(38,'Tribuna Sur',14600,10),(39,'Tribuna Este',21900,10),(40,'Tribuna Oeste',21900,10),(41,'Tribuna Norte',14000,11),(42,'Tribuna Sur',14000,11),(43,'Tribuna Este',21000,11),(44,'Tribuna Oeste',21000,11),(45,'Tribuna Norte',13000,12),(46,'Tribuna Sur',13000,12),(47,'Tribuna Este',19500,12),(48,'Tribuna Oeste',19500,12),(49,'Tribuna Norte',16500,13),(50,'Tribuna Sur',16500,13),(51,'Tribuna Este',24750,13),(52,'Tribuna Oeste',24750,13),(53,'Tribuna Norte',13800,14),(54,'Tribuna Sur',13800,14),(55,'Tribuna Este',20700,14),(56,'Tribuna Oeste',20700,14),(57,'Tribuna Norte',14200,15),(58,'Tribuna Sur',14200,15),(59,'Tribuna Este',21300,15),(60,'Tribuna Oeste',21300,15),(61,'Tribuna Norte',13800,16),(62,'Tribuna Sur',13800,16),(63,'Tribuna Este',20700,16),(64,'Tribuna Oeste',20700,16);
/*!40000 ALTER TABLE `sector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sector_evento`
--

DROP TABLE IF EXISTS `sector_evento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sector_evento` (
  `id_sector` int NOT NULL,
  `id_evento` int NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `capacidad_disponible` int NOT NULL,
  PRIMARY KEY (`id_sector`,`id_evento`),
  KEY `fk_sector_evento_evento` (`id_evento`),
  CONSTRAINT `fk_sector_evento_evento` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id`),
  CONSTRAINT `fk_sector_evento_sector` FOREIGN KEY (`id_sector`) REFERENCES `sector` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector_evento`
--

LOCK TABLES `sector_evento` WRITE;
/*!40000 ALTER TABLE `sector_evento` DISABLE KEYS */;
INSERT INTO `sector_evento` VALUES (5,41,0.00,10800),(6,41,120.99,10800),(7,58,10.00,16200),(8,58,10.00,16200),(9,47,0.00,16600),(9,57,120.00,16600),(10,57,110.00,16600),(11,57,159.00,24900),(12,57,7.90,24900),(29,46,12.00,18800),(29,53,10.00,18800),(30,46,12.00,18800),(30,53,100.00,18800),(31,46,12.00,28200),(31,49,120.00,28200),(32,46,12.00,28200),(32,49,140.00,28200),(32,50,1.00,28200),(33,52,10.00,14444),(33,54,190.00,14444),(34,54,200.00,14444),(35,54,30.00,21666),(36,54,40.00,21666),(37,42,10.00,14600),(38,42,1.00,14600),(39,42,11.00,21900),(40,42,1.00,21900),(40,43,100.00,21900),(40,48,100.00,21900),(49,51,100.00,16500),(50,51,200.00,16500),(51,51,120.00,24750),(52,51,23.00,24750),(57,44,100.00,14200),(57,45,12.00,14200),(57,56,100.00,14200),(58,44,200.00,14200),(58,45,20.00,14200),(58,56,20.00,14200),(59,44,300.00,21300),(59,45,33.00,21300),(59,56,30.00,21300),(60,45,50.00,21300),(60,56,40.00,21300),(63,55,12.00,20700),(64,55,13.00,20700);
/*!40000 ALTER TABLE `sector_evento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sector_evento_funcionario_dispositivo`
--

DROP TABLE IF EXISTS `sector_evento_funcionario_dispositivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sector_evento_funcionario_dispositivo` (
  `mail_funcionario` varchar(255) NOT NULL,
  `id_dispositivo` int NOT NULL,
  `id_sector` int NOT NULL,
  `id_evento` int NOT NULL,
  PRIMARY KEY (`mail_funcionario`,`id_dispositivo`,`id_sector`,`id_evento`),
  KEY `fk_sefd_sector_evento` (`id_sector`,`id_evento`),
  CONSTRAINT `fk_sefd_fd` FOREIGN KEY (`mail_funcionario`, `id_dispositivo`) REFERENCES `funcionario_dispositivo` (`mail_funcionario`, `id_dispositivo`),
  CONSTRAINT `fk_sefd_sector_evento` FOREIGN KEY (`id_sector`, `id_evento`) REFERENCES `sector_evento` (`id_sector`, `id_evento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector_evento_funcionario_dispositivo`
--

LOCK TABLES `sector_evento_funcionario_dispositivo` WRITE;
/*!40000 ALTER TABLE `sector_evento_funcionario_dispositivo` DISABLE KEYS */;
/*!40000 ALTER TABLE `sector_evento_funcionario_dispositivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seleccion`
--

DROP TABLE IF EXISTS `seleccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seleccion` (
  `codigo_pais` char(3) NOT NULL,
  PRIMARY KEY (`codigo_pais`),
  CONSTRAINT `fk_seleccion_pais` FOREIGN KEY (`codigo_pais`) REFERENCES `pais` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seleccion`
--

LOCK TABLES `seleccion` WRITE;
/*!40000 ALTER TABLE `seleccion` DISABLE KEYS */;
INSERT INTO `seleccion` VALUES ('ARG'),('AUS'),('AUT'),('BEL'),('BIH'),('BRA'),('CAN'),('CHE'),('CIV'),('COL'),('CPV'),('CUW'),('CZE'),('DEU'),('DZA'),('ECU'),('EGY'),('ESP'),('FRA'),('GHA'),('HRV'),('HTI'),('IRN'),('IRQ'),('ITA'),('JOR'),('JPN'),('KOR'),('MAR'),('MEX'),('NLD'),('NOR'),('NZL'),('PAN'),('PRT'),('PRY'),('QAT'),('SAU'),('SEN'),('SWE'),('TUN'),('TUR'),('URY'),('USA'),('UZB'),('ZAF');
/*!40000 ALTER TABLE `seleccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telefono_usuario`
--

DROP TABLE IF EXISTS `telefono_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telefono_usuario` (
  `mail` varchar(255) NOT NULL,
  `telefono` varchar(30) NOT NULL,
  PRIMARY KEY (`mail`,`telefono`),
  CONSTRAINT `fk_telefono_usuario` FOREIGN KEY (`mail`) REFERENCES `usuario` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telefono_usuario`
--

LOCK TABLES `telefono_usuario` WRITE;
/*!40000 ALTER TABLE `telefono_usuario` DISABLE KEYS */;
INSERT INTO `telefono_usuario` VALUES ('mateo@gmail.com','123456'),('user1000@example.com','123456'),('user123@algo.com','123456'),('user12@example.com','091123456'),('user12@example.com','091233456'),('user12@example.com','099123123'),('user13@example.com','091987654'),('user13@example.com','099123456'),('user14@bolso.com','099123123'),('user14@example.com','091987654'),('user14@example.com','099123456'),('user15@example.com','091123456'),('user15@example.com','091233456'),('user15@example.com','099123123'),('user1899@bolso.com','099123123'),('user1@example.com','091987654'),('user1@example.com','099123456'),('user2@example.com','091987654'),('user2@example.com','099123456'),('user4@example.com','091987654'),('user4@example.com','099123456'),('usuario@example.com','099120100');
/*!40000 ALTER TABLE `telefono_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_documento`
--

DROP TABLE IF EXISTS `tipo_documento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_documento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tipo` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_documento`
--

LOCK TABLES `tipo_documento` WRITE;
/*!40000 ALTER TABLE `tipo_documento` DISABLE KEYS */;
INSERT INTO `tipo_documento` VALUES (3,'Cédula de Identidad'),(1,'DNI'),(2,'Pasaporte');
/*!40000 ALTER TABLE `tipo_documento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transferencia`
--

DROP TABLE IF EXISTS `transferencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transferencia` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_hora` datetime NOT NULL,
  `id_estado_transferencia` int NOT NULL,
  `mail_cliente_remitente` varchar(255) NOT NULL,
  `mail_cliente_destinatario` varchar(255) NOT NULL,
  `id_entrada` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_transferencia_remitente` (`mail_cliente_remitente`),
  KEY `fk_transferencia_destinatario` (`mail_cliente_destinatario`),
  KEY `fk_transferencia_entrada` (`id_entrada`),
  KEY `fk_transferencia_estado` (`id_estado_transferencia`),
  CONSTRAINT `fk_transferencia_destinatario` FOREIGN KEY (`mail_cliente_destinatario`) REFERENCES `cliente` (`mail`),
  CONSTRAINT `fk_transferencia_entrada` FOREIGN KEY (`id_entrada`) REFERENCES `entrada` (`id`),
  CONSTRAINT `fk_transferencia_estado` FOREIGN KEY (`id_estado_transferencia`) REFERENCES `estado_transferencia` (`id`),
  CONSTRAINT `fk_transferencia_remitente` FOREIGN KEY (`mail_cliente_remitente`) REFERENCES `cliente` (`mail`),
  CONSTRAINT `chk_clientes_distintos` CHECK ((`mail_cliente_remitente` <> `mail_cliente_destinatario`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transferencia`
--

LOCK TABLES `transferencia` WRITE;
/*!40000 ALTER TABLE `transferencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `transferencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `mail` varchar(255) NOT NULL,
  `hash_contrasena` varchar(255) NOT NULL,
  `codigo_pais_documento` char(3) NOT NULL,
  `id_tipo_documento` int NOT NULL,
  `numero_documento` varchar(50) NOT NULL,
  `codigo_pais_residencia` char(3) NOT NULL,
  `localidad` varchar(100) NOT NULL,
  `calle` varchar(150) NOT NULL,
  `numero_puerta` varchar(20) NOT NULL,
  `codigo_postal` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`mail`),
  KEY `fk_usuario_pais_residencia` (`codigo_pais_residencia`),
  KEY `fk_usuario_tipo_documento` (`id_tipo_documento`),
  KEY `fk_usuario_pais_documento` (`codigo_pais_documento`),
  CONSTRAINT `fk_usuario_pais_documento` FOREIGN KEY (`codigo_pais_documento`) REFERENCES `pais` (`codigo`),
  CONSTRAINT `fk_usuario_pais_residencia` FOREIGN KEY (`codigo_pais_residencia`) REFERENCES `pais` (`codigo`),
  CONSTRAINT `fk_usuario_tipo_documento` FOREIGN KEY (`id_tipo_documento`) REFERENCES `tipo_documento` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES ('adminCAN@fifa.com','$2b$12$ppBt4Yolr72oWLfL66aKP.zuHKvQYqHePXH.Ie7zQeytKHRePO9CC','CAN',2,'12345678','CAN','Toronto','Calle Falsa','123','1100'),('adminMEX@fifa.com','$2b$12$1qzi5/7FRr8VHHFvZ/HGH.vG5/dUGw8zuB3TqYWzj4xioXGzxqWUi','MEX',2,'12345678','MEX','Ciudad de México','Calle Falsa','123','1200'),('adminUSA@fifa.com','$2b$12$zUjqJKUxFR.Nh2DvXgB1leyZ11lbBlHccXQMsnHSuPe9Ol0xOw9KK','USA',2,'12345678','USA','New York','Calle Falsa','123','1300'),('funcionario1@fifa.com','$2b$12$mfCzuJl5PhhbsqJ8ktaMPO16pzgSAjrI551fnQdJVxMNz6wuwM73y','URY',3,'87654321','URY','Montevideo','Calle Falsa','123','1400'),('funcionario2@fifa.com','$2b$12$N18B/n.inS/fX66Md32Lm.MStXHsLwC6BOBIdD3ue.MHm5A02z0IS','ARG',1,'87654321','ARG','Buenos Aires','Calle Falsa','123','1500'),('mateo@gmail.com','$2b$12$Ci7nKkfXuM1x70akgupnI.ByV/T8D7vE5VQa.P4rgPWmAhS9ijQ/K','CUB',2,'dfaf','AFG','asddf','afsdfas','3412','dfasfa'),('user1000@example.com','$2b$12$uQ1vM5lgO9AcTI886q7eleidlESByn28Q0MbZReTTlHRV.D7qya2.','CRI',1,'456789','SWZ','Ciudad x','Calle x','1000','1010290'),('user123@algo.com','$2b$12$KRTeweoOiRlitUTpAdsgnu4ntXaHty.8hHvscUlRWUUTXf22TKmnu','DJI',1,'234567','LTU','Una localidad','Una calle','732478','412334'),('user12@example.com','$2b$12$3D9fW9Kqn1vGS7gr30VXUedrDMw59SN7xImh9TyMOPvb6IBt4H/7S','URY',3,'51231235','URY','Montevideo','Una Calle','1899','1899'),('user13@example.com','$2b$12$hEP7obECdpK6XNvMBGCFPOO4X/NvHWrfZjMFgCa5cJ1IQKR64ECjq','URY',2,'56234567','URY','Montevideo','18 de Julio','1234','11100'),('user14@bolso.com','$2b$12$ikak35qgy9UD6.1mabNdreK.zyQmxoexZRFrpO8eu0DRzMefzb8ha','URY',3,'51231235','URY','Montevideo','Una Calle','1899','1899'),('user14@example.com','$2b$12$XctrALv6W8GBC4XX7o1PGOOXTRLEghT3BH8c9q7Pt/SM2u8AGuTOS','URY',2,'56234567','URY','Montevideo','18 de Julio','1234','11100'),('user15@example.com','$2b$12$Yxxq1.ZYpgBbqSA1WqOHUuFO71POkTenwLdpFlBJrBISS.LdErDDG','URY',3,'51231235','BGD','Montevideo','Una Calle','1899','1899'),('user1899@bolso.com','$2b$12$Nf7UnRiU6ARgx8T2.H1RBOMOUkWRcylUuhtb9yQIRQsFNGe/MoBsC','URY',3,'51231235','URY','Montevideo','Una Calle','1899','1899'),('user1@example.com','$2b$12$/VwpHbmtXN4VOFCSjwDIHukaiWz.FXZRi1zgsGhbK9ipa.XbGF3Bm','URY',1,'51234567','URY','Montevideo','18 de Julio','1234','11100'),('user2@example.com','$2b$12$AxR2cbHXNixIX37zwXgFEeB4tIspuTEmvohD33l1ZL/Z59HKV1RDK','URY',3,'51234567','URY','Montevideo','18 de Julio','1234','11100'),('user4@example.com','$2b$12$md4h/9u87QETaOZAAnj8Ee0c3IasHDeCP1sxnswOLl6pfhpTAzlq2','URY',2,'56234567','URY','Montevideo','18 de Julio','1234','11100'),('usuario@example.com','$2b$12$JqZlSlaP84sHlLFYGnfQDOy0WmMv/wx0XqOXDXOP.M0Tl2HLSsKba','BFA',2,'456789','CHN','China Town','Callejón','111','11111');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `validacion`
--

DROP TABLE IF EXISTS `validacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validacion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_hora` datetime NOT NULL,
  `codigo_qr` varchar(255) NOT NULL,
  `mail_funcionario` varchar(255) NOT NULL,
  `id_dispositivo` int NOT NULL,
  `id_entrada` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_entrada` (`id_entrada`),
  KEY `fk_validacion_fd` (`mail_funcionario`,`id_dispositivo`),
  CONSTRAINT `fk_validacion_entrada` FOREIGN KEY (`id_entrada`) REFERENCES `entrada` (`id`),
  CONSTRAINT `fk_validacion_fd` FOREIGN KEY (`mail_funcionario`, `id_dispositivo`) REFERENCES `funcionario_dispositivo` (`mail_funcionario`, `id_dispositivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `validacion`
--

LOCK TABLES `validacion` WRITE;
/*!40000 ALTER TABLE `validacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `validacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_hora` datetime NOT NULL,
  `id_estado_venta` int NOT NULL,
  `monto_total` decimal(12,2) NOT NULL,
  `porcentaje_comision` decimal(5,2) NOT NULL,
  `mail_cliente` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_venta_estado` (`id_estado_venta`),
  KEY `fk_venta_cliente` (`mail_cliente`),
  CONSTRAINT `fk_venta_cliente` FOREIGN KEY (`mail_cliente`) REFERENCES `cliente` (`mail`),
  CONSTRAINT `fk_venta_estado` FOREIGN KEY (`id_estado_venta`) REFERENCES `estado_venta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'XR_Grupo8'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-13 20:21:48
